from scraper import scrape_businesses
from gpt_analysis import analyze_business_with_gpt
from html_report import build_html_report, save_report_as_pdf
from email_sender import send_email
from config import TIERS, EMAIL_FROM

import datetime


def run_lead_generation(niche, location, email, count, service):
    try:
        print("🔍 Starting business scraping...")
        leads = scrape_businesses(niche, location, limit=count)
        print(f"✅ Scraped {len(leads)} businesses.\n")

        if not leads:
            print("❌ No leads found. Exiting.")
            return

        print("🤖 Running GPT analysis...")
        analyzed = []

        for index, lead in enumerate(leads):
            print(f"🔎 ({index + 1}/{len(leads)}) Analyzing: {lead.get('name')}")
            try:
                gpt_result = analyze_business_with_gpt(lead, service)

                if not all(k in gpt_result for k in ("opportunities", "pitch", "why_now", "growth")):
                    print(f"⚠️ Incomplete GPT response for: {lead.get('name')}")
                    continue

                enriched_lead = {**lead, **gpt_result}
                analyzed.append(enriched_lead)
                print("✅ GPT analysis complete.\n")

            except Exception as gpt_err:
                print(f"⚠️ GPT failed for {lead.get('name')}: {gpt_err}")

        if not analyzed:
            print("❌ No leads were successfully analyzed. Exiting.")
            return

        print("📄 Generating report...")
        price = TIERS[count]
        html = build_html_report(analyzed, count, price)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        filename = f"leads_{niche}_{location}_{count}_{timestamp}.pdf"
        pdf_path = save_report_as_pdf(html, filename)
        print(f"🧾 PDF saved as: {filename}")

        print("📬 Sending report...")
        subject = "Your LeadSiphon Lead Report"
        body = (
            f"Hi there,\n\n"
            f"Your LeadSiphon report for {count} '{niche}' leads in {location} is attached.\n"
            f"Each lead includes GPT-powered insights, outreach tips, and growth signals tailored for your service: {service}.\n\n"
            f"Total: ${price:.2f}\n\nThanks for using LeadSiphon!"
        )

        sent = send_email(email, subject, body, pdf_path)
        if sent:
            print(f"✅ Report successfully emailed to {email}")
        else:
            print("❌ Email failed. Check Mailgun configuration or logs.")

    except Exception as err:
        print("❌ Critical error occurred:", err)


if __name__ == "__main__":
    print("🎯 Welcome to LeadSiphon\n")

    niche = input("Enter a business niche (e.g., yoga studio): ")
    location = input("Enter a city or region: ")
    service = input("What service are you offering? (e.g., SEO, web design): ")
    email = input("Enter your email to receive the leads: ")

    print("\n📦 Lead Packages:")
    for qty, price in TIERS.items():
        print(f"  {qty} leads - ${price}")

    while True:
        try:
            lead_count = int(input("\nHow many leads would you like? (5, 25, 50, 100): "))
            if lead_count in TIERS:
                break
            else:
                print("⚠️ Please enter a valid lead count.")
        except ValueError:
            print("⚠️ Please enter a number.")

    print(f"\n🔎 Finding {lead_count} leads for '{niche}' in '{location}'...\n")
    run_lead_generation(niche, location, email, lead_count, service)

