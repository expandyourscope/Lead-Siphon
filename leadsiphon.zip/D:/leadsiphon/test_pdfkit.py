import pdfkit
from config import WKHTMLTOPDF_PATH

html = "<h1>PDF Test</h1><p>This verifies wkhtmltopdf works.</p>"
config = pdfkit.configuration(wkhtmltopdf=WKHTMLTOPDF_PATH)
pdfkit.from_string(html, "test_output.pdf", configuration=config)
print("✅ PDF generated successfully.")
