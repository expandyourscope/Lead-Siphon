import requests
from bs4 import BeautifulSoup

def extract_website_text(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        return ' '.join(soup.stripped_strings)
    except Exception as e:
        print(f"Error fetching website: {url} — {e}")
        return ""
