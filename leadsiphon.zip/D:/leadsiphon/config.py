import os
from dotenv import load_dotenv

load_dotenv()

# ✅ Look for variable names (NOT actual values)
OPENAI_API_KEY     = os.getenv("OPENAI_API_KEY")
GOOGLE_API_KEY     = os.getenv("GOOGLE_API_KEY")
MAILGUN_API_KEY    = os.getenv("MAILGUN_API_KEY")
MAILGUN_DOMAIN     = os.getenv("MAILGUN_DOMAIN")
WKHTMLTOPDF_PATH   = os.getenv("WKHTMLTOPDF_PATH")

# Tier pricing
TIERS = {
    5: 9.99,
    25: 19.99,
    50: 29.99,
    100: 49.99
}

# Email sender
EMAIL_FROM = f"LeadSiphon <leads@{MAILGUN_DOMAIN}>"

# ✅ Optional debug
print("✅ ENV DEBUG:")
print("MAILGUN_DOMAIN =", repr(MAILGUN_DOMAIN))
print("WKHTMLTOPDF_PATH =", repr(WKHTMLTOPDF_PATH))
