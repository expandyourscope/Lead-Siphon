import requests
from config import MAILGUN_API_KEY, MAILGUN_DOMAIN, EMAIL_FROM

def send_email(to_email, subject, body_text, attachment_path):
    print("📤 Sending email...")

    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; background-color: #f9f9f9; padding: 30px;">
            <div style="max-width: 600px; background: white; margin: auto; border: 1px solid #eee; padding: 30px; border-radius: 8px;">
                <h2 style="color: #2c3e50;">Your LeadSiphon Report is Ready</h2>

                <p>Hi there,</p>

                <p>Thanks for using <strong>LeadSiphon</strong> to generate AI-analyzed business leads tailored to your service offering. Your custom PDF report is attached.</p>

                <p><strong>This report includes:</strong></p>
                <ul>
                    <li>Pre-qualified leads in your chosen niche & location</li>
                    <li>AI-powered opportunities & sales pitches</li>
                    <li>Growth indicators and outreach timing tips</li>
                </ul>

                <p style="margin-top: 30px;">Want more leads?</p>
                <a href="https://www.expandyourscope.com/coming-soon-03" 
                   style="display: inline-block; padding: 12px 24px; background-color: #0a74da; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">
                   ➕ Get More Leads!
                </a>

                <p style="margin-top: 30px;">Thanks again,<br><strong>The LeadSiphon Team</strong></p>

                <hr style="margin-top: 40px;">
                <p style="font-size: 12px; color: #999;">LeadSiphon • AI-powered outreach automation<br>{MAILGUN_DOMAIN}</p>
            </div>
        </body>
    </html>
    """

    response = requests.post(
        f"https://api.mailgun.net/v3/{MAILGUN_DOMAIN}/messages",
        auth=("api", MAILGUN_API_KEY),
        files=[("attachment", open(attachment_path, "rb"))],
        data={
            "from": EMAIL_FROM,
            "to": [to_email],
            "subject": subject,
            "text": body_text,   # fallback plain text
            "html": html_body    # primary content
        }
    )

    return response.status_code == 200
