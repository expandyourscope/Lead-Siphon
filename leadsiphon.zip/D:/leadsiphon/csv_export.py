import csv

def save_to_csv(lead_list, filename):
    with open(filename, 'w', newline='', encoding='utf-8') as file:
        fieldnames = [
            'Business Name',
            'Website',
            'Address',
            'Growth Signals',
            'Weaknesses',
            'Opportunities',
            'Readiness Score',
            'Why Now?',
            'Suggested Pitch'
        ]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for lead in lead_list:
            writer.writerow(lead)
