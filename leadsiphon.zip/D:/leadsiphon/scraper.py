import requests
from config import GOOGLE_API_KEY

def scrape_businesses(niche, location, limit=25):
    query = f"{niche} in {location}"
    endpoint = "https://maps.googleapis.com/maps/api/place/textsearch/json"
    params = {
        "query": query,
        "key": GOOGLE_API_KEY
    }

    response = requests.get(endpoint, params=params)
    data = response.json()
    businesses = []

    for place in data.get("results", [])[:limit]:
        if not place.get("business_status") == "OPERATIONAL":
            continue

        business = {
            "name": place.get("name"),
            "address": place.get("formatted_address"),
            "place_id": place.get("place_id"),
            "website": get_website_for_place(place.get("place_id")),
            "source": "primary"  # Track for PDF labeling
        }
        businesses.append(business)

    return businesses


def get_website_for_place(place_id):
    endpoint = "https://maps.googleapis.com/maps/api/place/details/json"
    params = {
        "place_id": place_id,
        "fields": "website",
        "key": GOOGLE_API_KEY
    }
    response = requests.get(endpoint, params=params)
    result = response.json().get("result", {})
    return result.get("website", "")


def suggest_fallback_niches(niche):
    niche_map = {
        "yoga": ["pilates", "fitness studio", "massage therapy"],
        "horse riding": ["equestrian center", "outdoor adventure", "farm tours"],
        "dentist": ["orthodontist", "dental clinic", "oral surgeon"],
        "marketing agency": ["branding agency", "seo company", "creative consultant"],
        "web design": ["digital agency", "IT consulting", "graphic design"],
        # Add more as needed
    }
    return niche_map.get(niche.lower(), ["consulting", "freelancer", "local service"])


def scrape_with_fallback(primary_niche, location, limit=25, fallback_niches=None):
    print(f"🔍 Scraping primary niche: '{primary_niche}'...")
    primary_leads = scrape_businesses(primary_niche, location, limit)

    if len(primary_leads) >= limit:
        return primary_leads[:limit]

    print(f"⚠️ Only found {len(primary_leads)} leads. Searching fallback niches...")

    fallback_niches = fallback_niches or suggest_fallback_niches(primary_niche)
    needed = limit - len(primary_leads)
    secondary_leads = []

    for niche in fallback_niches:
        print(f"🔄 Trying fallback niche: '{niche}'...")
        leads = scrape_businesses(niche, location, limit=needed)
        for lead in leads:
            lead["source"] = "secondary"
        secondary_leads.extend(leads)
        if len(secondary_leads) >= needed:
            break

    all_leads = primary_leads + secondary_leads
    print(f"✅ Total leads returned: {len(all_leads)}")
    return all_leads[:limit]
