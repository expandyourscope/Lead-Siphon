from flask import Flask, request
from main import run_lead_generation

app = Flask(__name__)

@app.route('/trigger', methods=['POST'])
def trigger():
    data = request.get_json()

    required = ['niche', 'location', 'service', 'email', 'count']
    if not all(k in data for k in required):
        return {"error": "Missing required fields"}, 400

    try:
        run_lead_generation(
            niche=data['niche'],
            location=data['location'],
            email=data['email'],
            count=int(data['count']),
            service=data['service']
        )
        return {"status": "success"}, 200
    except Exception as e:
        return {"error": str(e)}, 500

if __name__ == '__main__':
    app.run(debug=True)
