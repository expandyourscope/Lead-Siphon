import openai
import json
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

def analyze_business_with_gpt(business: dict, user_service: str) -> dict:
    prompt = f"""
You are an AI marketing strategist helping a freelancer who offers '{user_service}' services.

Analyze this business and generate an outreach strategy directed **at them**.

Business:
- Name: {business.get('name', 'N/A')}
- Website: {business.get('website', 'N/A')}
- Address: {business.get('address', 'N/A')}

Reply ONLY in this JSON format:

{{
  "opportunities": "What this business could improve or do better with help from your service.",
  "pitch": "A 1–2 sentence pitch from the freelancer directly TO the business owner.",
  "why_now": "Why it's a smart time to reach out and offer help.",
  "growth": "Any signs of growth (or risks) based on their website or industry."
}}
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )

        text = response.choices[0].message.content.strip()

        if text.startswith("```json"):
            text = text.lstrip("```json").rstrip("```").strip()

        result = json.loads(text)

        expected_keys = ["opportunities", "pitch", "why_now", "growth"]
        if not all(k in result for k in expected_keys):
            raise ValueError("Missing keys in GPT response.")

        return result

    except Exception as e:
        print(f"⚠️ GPT analysis failed for {business.get('name')}: {e}")
        return {
            "opportunities": "GPT analysis failed.",
            "pitch": "Manual pitch required.",
            "why_now": "Could not determine urgency.",
            "growth": "No data available."
        }
