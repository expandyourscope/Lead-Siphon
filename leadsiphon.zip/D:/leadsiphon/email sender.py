import smtplib
from email.message import EmailMessage
from config import EMAIL_HOST, EMAIL_PORT, EMAIL_ADDRESS, EMAIL_PASSWORD

def send_email_with_csv(to_email, file_path):
    msg = EmailMessage()
    msg['Subject'] = "Your AI-Scored Lead List"
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = to_email
    msg.set_content("Your custom lead list is attached. Let us know if you'd like more leads!")

    with open(file_path, 'rb') as f:
        file_data = f.read()
        msg.add_attachment(file_data, maintype='application', subtype='octet-stream', filename=file_path)

    with smtplib.SMTP_SSL(EMAIL_HOST, EMAIL_PORT) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        smtp.send_message(msg)
        print(f"✅ Email sent to {to_email}")
