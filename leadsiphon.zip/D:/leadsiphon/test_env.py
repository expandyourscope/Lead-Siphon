from dotenv import load_dotenv
import os

load_dotenv()

print("MAILGUN_DOMAIN =", os.getenv("MAILGUN_DOMAIN"))
print("WKHTMLTOPDF_PATH =", os.getenv("WKHTMLTOPDF_PATH"))
