flask
gunicorn
requests
openai
pdfkit
python-dotenv
jinja2